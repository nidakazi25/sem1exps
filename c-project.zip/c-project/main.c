#include <stdio.h>
int main() 
{    printf("==================================================\n");
    printf("\t STUDENT PROFILE CARD\n");
printf("==================================================\n");
    printf("Name\t\t: \tNida Kazi\n");
    printf("Course\t\t: \tFE Computer Engineering\n");
    printf("UIN.\t\t: \t261P094\n");
    printf("Roll No.\t: \t20\n");
printf("==================================================\n");
    return 0;
}
